public class Blackjack {
    public static void main(String[] args){

        System.out.println("Welcome to CSA Blackjack!");

        Deck deckCreation = new Deck();
        deckCreation.fullDeckCreator();

        System.out.println(deckCreation);

    }
}
