import java.lang.reflect.Array;
import java.util.ArrayList;

public class Deck {

    //Instance
    public ArrayList<Card> cards;

    //Constuctor
    public Deck(){
        this.cards = new ArrayList<Card>();
    }

    //Iterating through all the enums
    public void fullDeckCreator(){
        for(Suit cardSuit : Suit.values()){
            for(Values cardValue : Values.values()){
                this.cards.add(new Card(cardSuit, cardValue));  //Adding a new card to the deck
            }
        }
    }

    public String toString(){
        String cardListReturn = "";
        int i = 0;  //testing variable
        for(Card aCard : this.cards){
            cardListReturn += "\n" + i + "-" + aCard.toString();
            i++;
        }

        return cardListReturn;

    }

}
