import java.util.Scanner;

public class Blackjack {
    public static void main(String[] args){

        System.out.println("Welcome to CSA Blackjack!");

        Deck deckCreation = new Deck();

        deckCreation.fullDeckCreator();

        deckCreation.shuffleDeck();


        Deck playerDeck = new Deck();   //This contains the cards that the player will have in their hand
        Deck dealerDeck = new  Deck();  //Cards for the dealer

        Scanner scannerCash = new Scanner(System.in);
        System.out.println("How much cash are you willing to play with?");
        double playerCash = scannerCash.nextDouble();

        Scanner scanner = new Scanner(System.in);

        while(playerCash > 0){
            System.out.println("Great! With your $" + playerCash + ", how much would you like to bet?");
            double playerBet  = scanner.nextDouble();
            if(playerBet > playerCash){
                System.out.println("You cannot bet more than what you currently have. Please leave.");
                break;  //Breaks outs of the loop
            }

            boolean endRound = false;

            playerDeck.draw(deckCreation);
            playerDeck.draw(deckCreation);  //We are taking two cards away from the main deck and putting it into the hand of the player(twice because the player starts with two cards)

            dealerDeck.draw(deckCreation);
            dealerDeck.draw(deckCreation);

            while(true){
                System.out.print("Your hand: ");
                System.out.println(playerDeck.toString());
                System.out.println("Your hand has a total value of: " + playerDeck.cardsValue());

                System.out.println();

                System.out.println("Dealer hand: " + dealerDeck.getCard(0).toString() + " and ________");

                System.out.println("Would you like to Hit or Stand?");
                String response = scanner.nextLine();

                if(response.equalsIgnoreCase("hit")){
                    playerDeck.draw(deckCreation);
                    System.out.println("You draw a: " + playerDeck.getCard(playerDeck.deckSize() - 1).toString()); //get the most recently added card

                    if(playerDeck.cardsValue() > 21){
                        System.out.println("Bust. Currently valued at: " + playerDeck.cardsValue());
                        playerCash -= playerBet;
                        endRound = true;
                        break;
                    }
                }

                if(response.equalsIgnoreCase("stand")){
                    break;
                }
            }

            System.out.println("Dealer Cards: " + dealerDeck.toString());
            if(dealerDeck.cardsValue() > playerDeck.cardsValue() && endRound == false){
                System.out.println("Dealer won!");
                playerCash -= playerBet;
                endRound = true;
            }

            while(dealerDeck.cardsValue() < 17 && endRound == false){
                dealerDeck.draw(deckCreation);
                System.out.println("Dealer Daws: " + dealerDeck.getCard(dealerDeck.deckSize() - 1).toString());
            }


            System.out.println("Dealers hand is valued at: " +dealerDeck.cardsValue());

            if(dealerDeck.cardsValue() > 21 && endRound == false){
                System.out.println("Dealer busts! You win.");
                playerCash += playerBet;
                endRound = true;
            }

            if(playerDeck.cardsValue() == dealerDeck.cardsValue() && endRound == false){
                System.out.println("Tie");
                endRound = true;
            }

            if(playerDeck.cardsValue() > dealerDeck.cardsValue() && endRound == false){
                System.out.println("You win the hand!");
                playerCash += playerBet;
                endRound = true;
            } else if(endRound == false){
                System.out.println("You lose the hand.");
                playerCash -= playerBet;
                endRound = true;
            }

            playerDeck.returnCardsToDeck(deckCreation);
            dealerDeck.returnCardsToDeck(deckCreation); //Moving all the handed cards back into the deck

            System.out.println("End of hand.");

        }

        System.out.println("GG, you are not out of money. Bye have a great time");

    }
}
