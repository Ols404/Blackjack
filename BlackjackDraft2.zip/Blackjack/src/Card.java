public class Card {

    private Suit suit;
    private Values value;

    public Card(Suit suit, Values value){
        this.suit = suit;
        this.value = value;
    }

    public String toString(){
        return this.suit.toString()  + "-" + this.value.toString(); //returns the suit and the value
    }

    public Values getValue(){
        return this.value;
    }

}
